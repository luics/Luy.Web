//
//  MobadsTestAppDelegate.h
//  BaiduMobadsWebView
//
//  Created by shao bo on 13-3-13.
//  Copyright (c) 2013年 baidu. All rights reserved.
//

#import <UIKit/UIKit.h>

@class MobadsTestViewController;

@interface MobadsTestAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@property (strong, nonatomic) MobadsTestViewController *viewController;

@end
