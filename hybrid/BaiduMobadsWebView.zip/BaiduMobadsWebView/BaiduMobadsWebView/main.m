//
//  main.m
//  BaiduMobadsWebView
//
//  Created by shao bo on 13-3-13.
//  Copyright (c) 2013年 baidu. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "MobadsTestAppDelegate.h"

int main(int argc, char *argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([MobadsTestAppDelegate class]));
    }
}
