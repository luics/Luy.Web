//
//  MobadsTestViewController.h
//  BaiduMobadsWebView
//
//  Created by shao bo on 13-3-13.
//  Copyright (c) 2013年 baidu. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MobadsTestViewController : UIViewController<UITextFieldDelegate>{
    UIButton *_coverView;
}
@property (retain, nonatomic) IBOutlet UITextField *urlField;
@property (retain, nonatomic) IBOutlet UIWebView *mWebView;
@property (retain, nonatomic) IBOutlet UIButton *goButton;

@end
