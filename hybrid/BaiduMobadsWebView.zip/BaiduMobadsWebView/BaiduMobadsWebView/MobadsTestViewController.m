//
//  MobadsTestViewController.m
//  BaiduMobadsWebView
//
//  Created by shao bo on 13-3-13.
//  Copyright (c) 2013年 baidu. All rights reserved.
//

#import "MobadsTestViewController.h"

@interface MobadsTestViewController ()

@end

@implementation MobadsTestViewController
- (IBAction)clickGo:(id)sender {
    if (_urlField.text && ![[_urlField text] isEqualToString:@""]) {
        [self.mWebView loadRequest:[NSURLRequest requestWithURL:[NSURL URLWithString:[NSString stringWithFormat:@"http://%@",_urlField.text]]]];
    }
}

- (BOOL)textFieldShouldBeginEditing:(UITextField *)textField
{
    _coverView.frame = self.view.frame;
    return YES;
}


- (void)viewDidLoad
{
    [super viewDidLoad];
    self.urlField.delegate = self;
    _coverView = [[UIButton alloc] initWithFrame:CGRectZero];
	// Do any additional setup after loading the view, typically from a nib.
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)dealloc {
    [_urlField release];
    [_goButton release];
    [_mWebView release];
    [_coverView release];
    [super dealloc];
}
@end
